package com.example.capstone;

import android.util.JsonReader;

public interface APICallBack {
    void callBack(JsonReader jsonObject);
}
